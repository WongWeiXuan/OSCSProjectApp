package email.model;

public class FileEncryptionException extends Exception{
	 /**
	 * 
	 */
	private static final long serialVersionUID = 563547166180817203L;

	public FileEncryptionException(String message) {
	        super(message);
	    }
}
